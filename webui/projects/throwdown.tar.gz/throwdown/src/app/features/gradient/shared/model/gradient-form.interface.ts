export interface GradientForm {
  inner: string;
  outer: string;
  recipient: string;
}
