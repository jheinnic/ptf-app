import * as Commands from './commands';
import * as Models from './models';
export * from './selectors';

export interface State
{
  facadeStatus: Models.KeycloakFacadeStatus;
  selectedClientName?: string;
  errorDetail?: Models.ErrorDetail;
}

export const initialState: State = {
  facadeStatus: Models.KeycloakFacadeStatus.SetClient,
  selectedClientName: undefined,
  errorDetail: {
    errorCause: Models.ErrorCause.Pending,
    displayMessage: undefined
  }
};

export function reducer(state = initialState, action: Commands.CommandType): State
{
  switch (action.type) {
    case Commands.ASSIGN_KEYCLOAK_CLIENT:
    {
      return {
        ...state,
        facadeStatus: Models.KeycloakFacadeStatus.Bootstrap,
        selectedClientName: action.payload
      };
    }

    case Commands.MARK_BOOTSTRAP_AS_DONE:
    {
      return {
        ...state,
        facadeStatus: Models.KeycloakFacadeStatus.Ready
      };
    }

    case Commands.MARK_BOOTSTRAP_AS_FAILED:
    {
      return {
        ...state,
        facadeStatus: Models.KeycloakFacadeStatus.Error,
        errorDetail: action.payload
      };
    }

    default:
    {
      return state;
    }
  }
}
