/*
 * Public API Surface of ngx-message-channels
 */

export * from './lib/ngx-message-channels.service';
export * from './lib/ngx-message-channels.component';
export * from './lib/ngx-message-channels.module';
