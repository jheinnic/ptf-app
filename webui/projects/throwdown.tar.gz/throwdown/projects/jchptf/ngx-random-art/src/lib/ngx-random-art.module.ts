import { NgModule } from '@angular/core';
import { NgxRandomArtComponent } from './ngx-random-art.component';

@NgModule({
  imports: [
  ],
  declarations: [NgxRandomArtComponent],
  exports: [NgxRandomArtComponent]
})
export class NgxRandomArtModule { }
