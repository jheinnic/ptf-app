export interface LeaseManager {

}
