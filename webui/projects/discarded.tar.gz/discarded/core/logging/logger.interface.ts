export abstract class Logger {
  info: any;
  warn: any;
  error: any;
}
