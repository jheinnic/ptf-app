import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'ngx-web3-indicator',
  template: `
    <p>
      ngx-web3 works!
    </p>
  `,
  styles: []
})
export class IndicatorComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
