import { Action } from '@ngrx/store';

export enum RecuActionTypes {
  LoadRecus = '[Recu] Load Recus'
}

export class LoadRecus implements Action {
  readonly type = RecuActionTypes.LoadRecus;
}

export type RecuActions = LoadRecus;
