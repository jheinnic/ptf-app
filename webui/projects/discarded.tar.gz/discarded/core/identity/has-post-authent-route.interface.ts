export interface HasPostAuthentRoute {
  getPostAuthUrl(): string;
}
