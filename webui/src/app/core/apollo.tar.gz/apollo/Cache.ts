import {DocumentNode} from 'graphql';
import {createSelector, Store} from '@ngrx/store';
import {ApolloCache, Cache as _Cache, DataProxy, Transaction} from 'apollo-cache';
import {addTypenameToDocument, getFragmentQueryDocument} from 'apollo-utilities';
import {take} from 'rxjs/operators';

import {HeuristicFragmentMatcher} from './utils/fragmentMatcher';
import {ApolloReducerConfig, NormalizedCache, OptimisticStoreItem,} from './types';
import {writeResultToStore} from './utils/writeToStore';
import {diffQueryAgainstStore, readQueryFromStore} from './utils/readFromStore';
import * as actions from './store/actions';

const defaultConfig: ApolloReducerConfig = {
  fragmentMatcher: new HeuristicFragmentMatcher().match,
  dataIdFromObject: defaultDataIdFromObject,
  addTypename: true,
};

export function defaultDataIdFromObject(result: any): string | null
{
  if (result.__typename) {
    if (result.id !== undefined) {
      return `${result.__typename}:${result.id}`;
    }
    if (result._id !== undefined) {
      return `${result.__typename}:${result._id}`;
    }
  }
  return null;
}

interface ApolloStore
{
  apollo: NormalizedCache;
}

export class Cache extends ApolloCache<NormalizedCache>
{
  private store: Store<ApolloStore>;

  private config: ApolloReducerConfig;

  private optimistic: OptimisticStoreItem[] = [];

  private watches: _Cache.WatchOptions[] = [];

  private addTypename: boolean;

  constructor(store: Store<any>, config: ApolloReducerConfig = {})
  {
    super();
    this.store = store;
    this.config = {...defaultConfig, ...config};
    this.addTypename = this.config.addTypename ? true : false;
  }

  public restore(data: NormalizedCache): ApolloCache<NormalizedCache>
  {
    if (data) { this.data = data; }
    return this;
  }

  public extract(optimistic: boolean = false): NormalizedCache
  {
    if (optimistic && this.optimistic.length > 0) {
      const patches = this.optimistic.map(opt => opt.data);
      return Object.assign({}, this.data, ...patches) as NormalizedCache;
    }

    return this.data;
  }

  public read<T>(query: _Cache.ReadOptions): T
  {
    if (query.rootId && typeof this.data[query.rootId] === 'undefined') {
      return null;
    }

    return readQueryFromStore({
      store: this.extract(query.optimistic),
      query: this.transformDocument(query.query),
      variables: query.variables,
      rootId: query.rootId,
      fragmentMatcherFunction: this.config.fragmentMatcher,
      previousResult: query.previousResult,
      config: this.config,
    });
  }

  public write(write: _Cache.WriteOptions): void
  {
    writeResultToStore({
      dataId: write.dataId,
      result: write.result,
      variables: write.variables,
      document: this.transformDocument(write.query),
      store: this.data,
      dataIdFromObject: this.config.dataIdFromObject,
      fragmentMatcherFunction: this.config.fragmentMatcher,
    });

    this.broadcastWatches();
  }

  public diff<T>(query: _Cache.DiffOptions): _Cache.DiffResult<T>
  {
    return diffQueryAgainstStore({
      store: this.extract(query.optimistic),
      query: this.transformDocument(query.query),
      variables: query.variables,
      returnPartialData: query.returnPartialData,
      previousResult: query.previousResult,
      fragmentMatcherFunction: this.config.fragmentMatcher,
      config: this.config,
    });
  }

  public watch(watch: _Cache.WatchOptions): () => void
  {
    this.watches.push(watch);

    return () => {
      this.watches = this.watches.filter(c => c !== watch);
    };
  }

  public evict(/*query: _Cache.EvictOptions*/): _Cache.EvictionResult
  {
    throw new Error(`eviction is not implemented on InMemory Cache`);
  }

  public reset(): Promise<void>
  {
    this.data = {};
    this.broadcastWatches();

    return Promise.resolve();
  }

  public removeOptimistic(id: string)
  {
    // Throw away optimistic changes of that particular mutation
    const toPerform = this.optimistic.filter(item => item.id !== id);

    this.optimistic = [];

    // Re-run all of our optimistic data actions on top of one another.
    toPerform.forEach(change => {
      this.recordOptimisticTransaction(change.transaction, change.id);
    });

    this.broadcastWatches();
  }

  public performTransaction(transaction: Transaction<NormalizedCache>)
  {
    // TODO: does this need to be different, or is this okay for an in-memory cache?
    transaction(this);
  }

  public recordOptimisticTransaction(
    transaction: Transaction<NormalizedCache>,
    id: string
  )
  {
    const before = this.extract(true);

    const orig = this.data;
    this.data = {...before};
    transaction(this);
    const after = this.data;
    this.data = orig;

    const patch: any = {};

    Object.keys(after)
      .forEach(key => {
        if (after[key] !== before[key]) {
          patch[key] = after[key];
        }
      });

    this.optimistic.push({
      id,
      transaction,
      data: patch,
    });

    this.broadcastWatches();
  }

  public transformDocument(document: DocumentNode): DocumentNode
  {
    if (this.addTypename) { return addTypenameToDocument(document); }
    return document;
  }

  public readQuery<QueryType, TVariables = any>(
    options: DataProxy.Query<TVariables>,
    optimistic: boolean = false
  ): QueryType
  {
    return this.read({
      query: options.query,
      variables: options.variables,
      optimistic,
    });
  }

  public readFragment<FragmentType, TVariables = any>(
    options: DataProxy.Fragment<TVariables>,
    optimistic: boolean = false
  ): FragmentType | null
  {
    return this.read({
      query: this.transformDocument(
        getFragmentQueryDocument(options.fragment, options.fragmentName)
      ),
      variables: options.variables,
      rootId: options.id,
      optimistic,
    });
  }

  public writeQuery<QueryType, TVariables = any>(
    options: DataProxy.WriteQueryOptions<QueryType, TVariables>
  ): void
  {
    this.write({
      dataId: 'ROOT_QUERY',
      result: options.data,
      query: this.transformDocument(options.query),
      variables: options.variables,
    });
  }

  public writeFragment<FragmentType, TVariables = any>(
    options: DataProxy.WriteFragmentOptions<FragmentType, TVariables>
  ): void
  {
    this.write({
      dataId: options.id,
      result: options.data,
      query: this.transformDocument(
        getFragmentQueryDocument(options.fragment, options.fragmentName)
      ),
      variables: options.variables,
    });
  }

  private broadcastWatches()
  {
    // right now, we invalidate all queries whenever anything changes
    this.watches.forEach(c => {
      const newData = this.diff({
        query: c.query,
        variables: c.variables,
        previousResult: c.previousResult(),
        optimistic: c.optimistic,
      });

      c.callback(newData);
    });
  }

  private get data()
  {
    let data: NormalizedCache;

    const selectApollo = (state: any) => state.apollo;
    const selectApolloStore = createSelector(selectApollo, (state: ApolloStore) => state.apollo);

    take
      .call(this.store.select(selectApolloStore), 1)
      .subscribe((result: NormalizedCache) => (
        data = result
      ));

    return data;
  }

  private set data(data)
  {
    this.store.dispatch(new actions.WriteStore(data));
  }
}
