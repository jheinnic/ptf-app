import { Injectable } from '@angular/core';
import { Actions, Effect } from '@ngrx/effects';


@Injectable()
export class RecuEffects {

  constructor(private actions$: Actions) {}
}
