export namespace ToymodModels {
  export interface State {
  }
}
