export interface GradientContract {

}
