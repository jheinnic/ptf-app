export enum KeycloakFacadeStatus {
  SetClient,
  Bootstrap,
  Error,
  Ready
}

export enum SessionStatus {
  Unknown,
  Pending,
  Authenticated,
  Anonymous,
  Malformed
}

export interface KeycloakClient {
  readonly adapterName: string;
}

export interface OnReturnUrlValue {
  readonly returnToUrl: string;
}

export interface OnReturnUrlKey {
  readonly stateKey: string;
}

export interface OnBootstrapResult {
  readonly authenticated: boolean;
}

export enum ErrorCause
{
  NoFailure, Pending, Server, Network, Application, TimeOut, Cancelled, AccessDenied, Unknown
}

export interface ErrorDetail
{
  readonly displayMessage?: string;
  readonly errorCause: ErrorCause;
}

