import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { StoreModule } from '@ngrx/store';
import * as fromJunk4 from './store/junk4.reducer';
import { EffectsModule } from '@ngrx/effects';
import { Junk4Effects } from './store/junk4.effects';
import { Junk4Component } from './junk4.component';

@NgModule({
  declarations: [Junk4Component],
  imports: [
    CommonModule,
    StoreModule.forFeature('junk4', fromJunk4.reducer),
    EffectsModule.forFeature([Junk4Effects])
  ]
})
export class Junk4Module { }
