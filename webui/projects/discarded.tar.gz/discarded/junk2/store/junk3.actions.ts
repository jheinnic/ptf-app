import { Action } from '@ngrx/store';
import { Update } from '@ngrx/entity';
import { Junk3 } from './junk3.model';

export enum Junk3ActionTypes {
  LoadJunk3s = '[Junk3] Load Junk3s',
  AddJunk3 = '[Junk3] Add Junk3',
  UpsertJunk3 = '[Junk3] Upsert Junk3',
  AddJunk3s = '[Junk3] Add Junk3s',
  UpsertJunk3s = '[Junk3] Upsert Junk3s',
  UpdateJunk3 = '[Junk3] Update Junk3',
  UpdateJunk3s = '[Junk3] Update Junk3s',
  DeleteJunk3 = '[Junk3] Delete Junk3',
  DeleteJunk3s = '[Junk3] Delete Junk3s',
  ClearJunk3s = '[Junk3] Clear Junk3s'
}

export class LoadJunk3s implements Action {
  readonly type = Junk3ActionTypes.LoadJunk3s;

  constructor(public payload: { junk3s: Junk3[] }) {}
}

export class AddJunk3 implements Action {
  readonly type = Junk3ActionTypes.AddJunk3;

  constructor(public payload: { junk3: Junk3 }) {}
}

export class UpsertJunk3 implements Action {
  readonly type = Junk3ActionTypes.UpsertJunk3;

  constructor(public payload: { junk3: Junk3 }) {}
}

export class AddJunk3s implements Action {
  readonly type = Junk3ActionTypes.AddJunk3s;

  constructor(public payload: { junk3s: Junk3[] }) {}
}

export class UpsertJunk3s implements Action {
  readonly type = Junk3ActionTypes.UpsertJunk3s;

  constructor(public payload: { junk3s: Junk3[] }) {}
}

export class UpdateJunk3 implements Action {
  readonly type = Junk3ActionTypes.UpdateJunk3;

  constructor(public payload: { junk3: Update<Junk3> }) {}
}

export class UpdateJunk3s implements Action {
  readonly type = Junk3ActionTypes.UpdateJunk3s;

  constructor(public payload: { junk3s: Update<Junk3>[] }) {}
}

export class DeleteJunk3 implements Action {
  readonly type = Junk3ActionTypes.DeleteJunk3;

  constructor(public payload: { id: string }) {}
}

export class DeleteJunk3s implements Action {
  readonly type = Junk3ActionTypes.DeleteJunk3s;

  constructor(public payload: { ids: string[] }) {}
}

export class ClearJunk3s implements Action {
  readonly type = Junk3ActionTypes.ClearJunk3s;
}

export type Junk3Actions =
 LoadJunk3s
 | AddJunk3
 | UpsertJunk3
 | AddJunk3s
 | UpsertJunk3s
 | UpdateJunk3
 | UpdateJunk3s
 | DeleteJunk3
 | DeleteJunk3s
 | ClearJunk3s;
