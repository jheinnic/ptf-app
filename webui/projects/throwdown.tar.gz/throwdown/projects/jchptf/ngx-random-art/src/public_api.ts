/*
 * Public API Surface of ngx-random-art
 */

export * from './lib/ngx-random-art.service';
export * from './lib/ngx-random-art.component';
export * from './lib/ngx-random-art.module';
