import { EntityState, EntityAdapter, createEntityAdapter } from '@ngrx/entity';
import { Junk3 } from './junk3.model';
import { Junk3Actions, Junk3ActionTypes } from './junk3.actions';

export interface State extends EntityState<Junk3> {
  // additional entities state properties
}

export const adapter: EntityAdapter<Junk3> = createEntityAdapter<Junk3>();

export const initialState: State = adapter.getInitialState({
  // additional entity state properties
});

export function reducer(
  state = initialState,
  action: Junk3Actions
): State {
  switch (action.type) {
    case Junk3ActionTypes.AddJunk3: {
      return adapter.addOne(action.payload.junk3, state);
    }

    case Junk3ActionTypes.UpsertJunk3: {
      return adapter.upsertOne(action.payload.junk3, state);
    }

    case Junk3ActionTypes.AddJunk3s: {
      return adapter.addMany(action.payload.junk3s, state);
    }

    case Junk3ActionTypes.UpsertJunk3s: {
      return adapter.upsertMany(action.payload.junk3s, state);
    }

    case Junk3ActionTypes.UpdateJunk3: {
      return adapter.updateOne(action.payload.junk3, state);
    }

    case Junk3ActionTypes.UpdateJunk3s: {
      return adapter.updateMany(action.payload.junk3s, state);
    }

    case Junk3ActionTypes.DeleteJunk3: {
      return adapter.removeOne(action.payload.id, state);
    }

    case Junk3ActionTypes.DeleteJunk3s: {
      return adapter.removeMany(action.payload.ids, state);
    }

    case Junk3ActionTypes.LoadJunk3s: {
      return adapter.addAll(action.payload.junk3s, state);
    }

    case Junk3ActionTypes.ClearJunk3s: {
      return adapter.removeAll(state);
    }

    default: {
      return state;
    }
  }
}

export const {
  selectIds,
  selectEntities,
  selectAll,
  selectTotal,
} = adapter.getSelectors();
