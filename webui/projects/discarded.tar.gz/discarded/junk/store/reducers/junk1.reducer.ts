import { Action } from '@ngrx/store';
import { Junk1Actions, Junk1ActionTypes } from '../actions/junk1.actions';

export interface State {

}

export const initialState: State = {

};

export function reducer(state = initialState, action: Junk1Actions): State {
  switch (action.type) {

    case Junk1ActionTypes.LoadJunk1s:
      return state;


    default:
      return state;
  }
}
