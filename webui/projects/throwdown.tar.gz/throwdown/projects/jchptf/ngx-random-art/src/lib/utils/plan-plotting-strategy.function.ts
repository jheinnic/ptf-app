// import {* as ndarray} from 'ndarray';
import {from} from 'rxjs/internal/observable/from';

export function()
{ }
