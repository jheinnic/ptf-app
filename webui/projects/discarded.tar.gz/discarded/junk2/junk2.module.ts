import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { Junk2RoutingModule } from './junk2-routing.module';
import { StoreModule } from '@ngrx/store';
import * as fromJunk2 from './store/junk2.reducer';
import { EffectsModule } from '@ngrx/effects';
import { Junk2Effects } from './store/junk2.effects';
import * as fromJunk3 from './store/junk3.reducer';

@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    Junk2RoutingModule,
    StoreModule.forFeature('junk2', fromJunk2.reducer),
    EffectsModule.forFeature([Junk2Effects]),
    StoreModule.forFeature('junk3', fromJunk3.reducer)
  ]
})
export class Junk2Module { }
