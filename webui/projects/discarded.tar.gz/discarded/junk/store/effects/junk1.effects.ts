import { Injectable } from '@angular/core';
import { Actions, Effect, ofType } from '@ngrx/effects';
import { Junk1ActionTypes } from '../actions/junk1.actions';

@Injectable()
export class Junk1Effects {

  @Effect()
  loadJunk1s$ = this.actions$.pipe(ofType(Junk1ActionTypes.LoadJunk1s));

  constructor(private actions$: Actions) {}
}
