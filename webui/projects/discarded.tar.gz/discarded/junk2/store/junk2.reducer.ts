import { Junk2Actions, Junk2ActionTypes } from './junk2.actions';
import * as fromJunk3 from './junk3.reducer';

export interface State {
  junk3: fromJunk3.State;
}

export const initialState: State = {
  junk3: fromJunk3.adapter.getInitialState({
    // additional entity state properties
  })
};

export function reducer(state = initialState, action: Junk2Actions): State {
  switch (action.type) {

    case Junk2ActionTypes.LoadJunk2s:
      return state;


    default:
      return state;
  }
}
