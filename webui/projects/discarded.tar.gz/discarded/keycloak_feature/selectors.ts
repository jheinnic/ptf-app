import * as Models from './models';
import {State} from './reducer';

// IMHO, Selectors play the role of query-side events from the event store broker insofar as they enable
// the kinds of triggered behaviors that are not command processing work.  If an Command said "Request X",
// triggered an emission of Event Actions that were reduced to the state change implied by satisfying a
// request for X, then some number of Selectors should observe the difference before and after these two
// state representations, and the resulting "Next" emissions from those selectors are highly correlated
// with the Event Actions they arose from.  "Event Actions" are to the write-side as "Selector Notifications"
// are to the read-side of the model.
//
// This is an important distinction as it creates an answer to questions about where to cause side effects
// such as making API calls and writing to files that are activities not governed by an Action model,
// although inseparable from its semantics.  Behaviors not associated with model state (e.g. mutation by
// reducer and command handling by event construction in a command handler) occur outside those roles.

export const isAuthClientBootstrapped = (state: State) =>
  state && state.facadeStatus === Models.KeycloakFacadeStatus.Ready;

export const isAuthClientSelectionMade = (state: State) =>
  state && state.selectedClientName !== undefined && state.selectedClientName !== null;

export const hasAuthClientAssertedSessionState = (state: State) =>
  state && state.sessionStatus !== Models.SessionStatus.Unknown && state.sessionStatus !== Models.SessionStatus.Pending;
