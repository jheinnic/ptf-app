import {ActivatedRouteSnapshot, CanActivate, Router} from '@angular/router';
import {Injectable} from '@angular/core';
import {Observable} from 'rxjs';
import 'rxjs/add/operator/take';
import 'rxjs/add/operator/map';
import {Store} from '@ngrx/store';

import {CoreFeature} from '../../store/reducers';

@Injectable()
export class AuthenticatedGuard implements CanActivate {
  constructor(private readonly store: Store<CoreFeature.State>, private readonly router: Router) {
  }

  canActivate(routeSnapshot: ActivatedRouteSnapshot): Observable<boolean> {
    return this.store.select(CoreFeature.hasValidLogin)
      .delayWhen(
        Observable.of,
        this.store.select(CoreFeature.isAuthentClientReady)
          .filter(value => value));
  }
}
