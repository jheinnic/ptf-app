import { TestBed, inject } from '@angular/core/testing';
import { provideMockActions } from '@ngrx/effects/testing';
import { Observable } from 'rxjs';

import { RecuEffects } from './recu.effects';

describe('RecuEffects', () => {
  let actions$: Observable<any>;
  let effects: RecuEffects;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        RecuEffects,
        provideMockActions(() => actions$)
      ]
    });

    effects = TestBed.get(RecuEffects);
  });

  it('should be created', () => {
    expect(effects).toBeTruthy();
  });
});
