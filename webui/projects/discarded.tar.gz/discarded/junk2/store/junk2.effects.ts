import { Injectable } from '@angular/core';
import { Actions, Effect, ofType } from '@ngrx/effects';
import { Junk2ActionTypes } from './junk2.actions';

@Injectable()
export class Junk2Effects {

  @Effect()
  loadJunk2s$ = this.actions$.pipe(ofType(Junk2ActionTypes.LoadJunk2s));

  constructor(private actions$: Actions) {}
}
