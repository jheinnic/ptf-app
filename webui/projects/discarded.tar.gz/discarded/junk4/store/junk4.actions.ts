import { Action } from '@ngrx/store';

export enum Junk4ActionTypes {
  LoadJunk4s = '[Junk4] Load Junk4s'
}

export class LoadJunk4s implements Action {
  readonly type = Junk4ActionTypes.LoadJunk4s;
}

export type Junk4Actions = LoadJunk4s;
