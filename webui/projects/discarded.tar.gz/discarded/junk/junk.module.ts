import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { JunkRoutingModule } from './junk-routing.module';
import { StoreModule } from '@ngrx/store';
import * as fromJunk from './store';
import * as fromJunk1 from './store/reducers/junk1.reducer';
import { EffectsModule } from '@ngrx/effects';
import { Junk1Effects } from './store/effects/junk1.effects';

@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    JunkRoutingModule,
    StoreModule.forFeature('junk', fromJunk.reducers, { metaReducers: fromJunk.metaReducers }),
    StoreModule.forFeature('junk1', fromJunk1.reducer),
    EffectsModule.forFeature([Junk1Effects]),
  ]
})
export class JunkModule { }
