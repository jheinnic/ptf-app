import { TestBed, inject } from '@angular/core/testing';
import { provideMockActions } from '@ngrx/effects/testing';
import { Observable } from 'rxjs';

import { Junk2Effects } from './junk2.effects';

describe('Junk2Effects', () => {
  let actions$: Observable<any>;
  let effects: Junk2Effects;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        Junk2Effects,
        provideMockActions(() => actions$)
      ]
    });

    effects = TestBed.get(Junk2Effects);
  });

  it('should be created', () => {
    expect(effects).toBeTruthy();
  });
});
