import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'ngx-rnd-art',
  template: `
    <p>
      ngx-rnd-art works!
    </p>
  `,
  styles: []
})
export class NgxRandomArtComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }
}
