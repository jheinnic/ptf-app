import { TestBed, inject } from '@angular/core/testing';
import { provideMockActions } from '@ngrx/effects/testing';
import { Observable } from 'rxjs';

import { Junk1Effects } from './junk1.effects';

describe('Junk1Effects', () => {
  let actions$: Observable<any>;
  let effects: Junk1Effects;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        Junk1Effects,
        provideMockActions(() => actions$)
      ]
    });

    effects = TestBed.get(Junk1Effects);
  });

  it('should be created', () => {
    expect(effects).toBeTruthy();
  });
});
