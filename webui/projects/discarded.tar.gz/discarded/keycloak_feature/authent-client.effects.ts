import {Injectable} from '@angular/core';
import {Router, RouterStateSnapshot} from '@angular/router';
import {Observable} from 'rxjs/Observable';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/do';
import 'rxjs/add/operator/exhaustMap';
import 'rxjs/add/operator/filter';
import 'rxjs/add/operator/mergeMap';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/take';
import 'rxjs/add/operator/withLatestFrom';
import 'rxjs/add/observable/combineLatest';
import 'rxjs/add/observable/of';
import 'rxjs/add/observable/from';
import 'rxjs/add/observable/zip';
import {LogService, LogServiceFactory} from 'ng2-log-service';
import {RouterCancelPayload} from '@ngrx/router-store';
import {Actions, Effect} from '@ngrx/effects';
import {Database} from '@ngrx/db';
import {Store} from '@ngrx/store';

import * as AuthentClientActions from './actions';
import {
  FindValidSession, ProcessLoginError, ProcessLogoutError, ProcessSignupError, ProcessUserInfoError,
  RedirectForLogin, RequestBeginLogin, RequestBeginLogout, RequestBeginSignup, RequestUserInfo
} from './actions';
import {getUserInfo, isClientBootstrapped, State} from './core-feature.reducer';

@Injectable()
export class AuthentClientEffects
{
  private readonly logService: LogService;


  constructor(
    private readonly actions$: Actions,
    private readonly store: Store<State>,
    private readonly db: Database,
    logServiceFactory: LogServiceFactory)
  {
    this.logService = logServiceFactory.newLogService();
    this.logService.namespace = 'AuthentClientEffects';
  }

}

