import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Junk4Component } from './junk4.component';
import { Store, StoreModule } from '@ngrx/store';

describe('Junk4Component', () => {
  let component: Junk4Component;
  let fixture: ComponentFixture<Junk4Component>;
  let store: Store<any>;

  beforeEach(async() => {
    TestBed.configureTestingModule({
      imports: [ StoreModule.forRoot({}) ],
      declarations: [ Junk4Component ]
    });

    await TestBed.compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(Junk4Component);
    component = fixture.componentInstance;
    store = TestBed.get(Store);

    spyOn(store, 'dispatch').and.callThrough();
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
