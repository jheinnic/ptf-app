/*
 * Public API Surface of ngx-ipfs
 */

export * from './lib/ipfs.service';
export * from './lib/ngx-ipfs.module';
