import { Component, OnInit } from '@angular/core';
import { Store } from '@ngrx/store';
import * as fromStore from './store/junk4.reducer';

@Component({
  selector: 'jchptf-junk4',
  templateUrl: './junk4.component.html',
  styleUrls: ['./junk4.component.css']
})
export class Junk4Component implements OnInit {

  constructor(private store: Store<fromStore.State>) { }

  ngOnInit() {
  }

}
