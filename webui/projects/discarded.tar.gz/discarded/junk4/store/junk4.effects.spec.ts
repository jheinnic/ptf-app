import { TestBed, inject } from '@angular/core/testing';
import { provideMockActions } from '@ngrx/effects/testing';
import { Observable } from 'rxjs';

import { Junk4Effects } from './junk4.effects';

describe('Junk4Effects', () => {
  let actions$: Observable<any>;
  let effects: Junk4Effects;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        Junk4Effects,
        provideMockActions(() => actions$)
      ]
    });

    effects = TestBed.get(Junk4Effects);
  });

  it('should be created', () => {
    expect(effects).toBeTruthy();
  });
});
