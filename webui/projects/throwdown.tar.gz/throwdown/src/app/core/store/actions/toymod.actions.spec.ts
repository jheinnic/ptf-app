import { LoadToymods } from './toymod.actions';

describe('LoadToymods', () => {
  it('should create an instance', () => {
    expect(new LoadToymods()).toBeTruthy();
  });
});
