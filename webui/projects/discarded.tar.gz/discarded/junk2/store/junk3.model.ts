export interface Junk3 {
  id: string;
}
