import { Injectable } from '@angular/core';
import { Actions, Effect, ofType } from '@ngrx/effects';
import { Junk4ActionTypes } from './junk4.actions';

@Injectable()
export class Junk4Effects {

  @Effect()
  loadJunk4s$ = this.actions$.pipe(ofType(Junk4ActionTypes.LoadJunk4s));

  constructor(private actions$: Actions) {}
}
