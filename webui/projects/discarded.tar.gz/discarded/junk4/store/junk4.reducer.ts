import { Action } from '@ngrx/store';
import { Junk4Actions, Junk4ActionTypes } from './junk4.actions';

export interface State {

}

export const initialState: State = {

};

export function reducer(state = initialState, action: Junk4Actions): State {
  switch (action.type) {

    case Junk4ActionTypes.LoadJunk4s:
      return state;


    default:
      return state;
  }
}
