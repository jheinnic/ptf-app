import { Recu } from './recu.actions';

describe('Recu', () => {
  it('should create an instance', () => {
    expect(new Recu()).toBeTruthy();
  });
});
