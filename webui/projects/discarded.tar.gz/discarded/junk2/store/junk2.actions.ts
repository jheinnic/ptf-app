import { Action } from '@ngrx/store';

export enum Junk2ActionTypes {
  LoadJunk2s = '[Junk2] Load Junk2s'
}

export class LoadJunk2s implements Action {
  readonly type = Junk2ActionTypes.LoadJunk2s;
}

export type Junk2Actions = LoadJunk2s;
