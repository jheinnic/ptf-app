/*
 * Public API Surface of ngx-web3
 */

export * from './lib/ngx-web3.service';
export * from './lib/ngx-web3.component';
export * from './lib/ngx-web3.module';
