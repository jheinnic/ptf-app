import {Action} from '@ngrx/store';
import * as Models from './models';
import {KeycloakProfile} from 'keycloak-js';

export const ASSIGN_KEYCLOAK_CLIENT = '(Command::Core Keycloak) Assign keycloak client';
export const REQUEST_LOGIN = '(Command::Core Keycloak) Request login';
export const REQUEST_LOGOUT = '(Command::Core Keycloak) Request logout';
export const REQUEST_SIGNUP = '(Command::Core Keycloak) Request signup';
export const REQUEST_GO_ON_RETURN_URL = '(Command::Core Keycloak) Request go to on-resume URL';
export const SET_ON_RETURN_URL = '(Command::Core Keycloak) Set on-resume URL';
export const LOAD_USER_PROFILE = '(Command::Core Keycloak) Load User Profile';
export const REFRESH_ACCESS_TOKEN = '(Command::Core Keycloak) Refresh access token';
export const MARK_BOOTSTRAP_AS_DONE = '(Command::Core Keycloak) Mark bootstrap complete';
export const MARK_BOOTSTRAP_AS_FAILED = '(Command::Core Keycloak) Mark bootstrap error';
export const REPORT_AUTHENTICATED = '(Command::Core Keycloak) Report authentication success';
export const REPORT_REFRESHED = '(Command::Core Keycloak) Report access token refresh';
export const REPORT_ACCESS_TOKEN_EXPIRED = 'Command:Core Keycloak) Report access token expired';
export const REPORT_REFRESH_TOKEN_EXPIRED = 'Command:Core Keycloak) Report refresh token expired';
export const REPORT_LOGGED_OUT = '(Command::Core Keycloak) Report logged out';
export const RECEIVE_USER_PROFILE = '(Command::Core Keycloak) Receive user profile';
export const HANDLE_AUTHENTICATION_ERROR = '(Command::Core Keycloak) Receive login or signup error';
export const HANDLE_TOKEN_REFRESH_ERROR = '(Command::Core Keycloak) Receive token refresh error';
export const HANDLE_USER_PROFILE_ERROR = '(Command::Core Keycloak) Receive user profile error';


export class AssignKeycloakClient implements Action {
  public readonly type = ASSIGN_KEYCLOAK_CLIENT;

  /**
   * @param {string} payload The encapsulated keycloak client name to assign.
   */
  constructor(public readonly payload: Models.KeycloakClient) { }
}

export class RequestLogin implements Action {
  public readonly type = REQUEST_LOGIN;
}

export class RequestLogout implements Action {
  public readonly type = REQUEST_LOGOUT;
}

export class RequestSignup implements Action {
  public readonly type = REQUEST_SIGNUP;
}

export class RequestGoOnReturnUrl implements Action {
  public readonly type = REQUEST_GO_ON_RETURN_URL;

  constructor (public readonly payload: Models.OnReturnUrlKey) { }
}

export class SetOnReturnUrl implements Action {
  public readonly type = SET_ON_RETURN_URL;

  /**
   * @param {string} payload The URL to redirect to on return.  Default homepage is used if omitted.
   */
  constructor(public readonly payload: Models.OnReturnUrlValue) { }
}

export class LoadUserProfile implements Action {
  public readonly type = LOAD_USER_PROFILE;
}

export class RefreshAccessToken implements Action {
  public readonly type = REFRESH_ACCESS_TOKEN;
}

export class MarkBootstrapAsDone implements Action
{
  public readonly type = MARK_BOOTSTRAP_AS_DONE;

  /**
   * @param {boolean} payload True if session credentials were found during bootstrap, otherwise false.
   */
  constructor(public readonly payload: Models.OnBootstrapResult) { }
}

export class MarkBootstrapAsFailed implements Action {
  public readonly type = MARK_BOOTSTRAP_AS_FAILED;

  constructor(public readonly payload: Models.ErrorDetail) { }
}

export class ReportAuthenticated implements Action {
  public readonly type = REPORT_AUTHENTICATED;
}

export class ReportRefreshed implements Action {
  public readonly type = REPORT_REFRESHED;
}

export class ReportAccessTokenExpired implements Action {
  public readonly type = REPORT_ACCESS_TOKEN_EXPIRED;
}

export class ReportRefreshTokenExpired implements Action {
  public readonly type = REPORT_REFRESH_TOKEN_EXPIRED;
}

export class ReportLoggedOut implements Action {
  public readonly type = REPORT_LOGGED_OUT;
}

export class HandleAuthenticationError implements Action {
  public readonly type = HANDLE_AUTHENTICATION_ERROR;

  constructor(public readonly payload: Models.ErrorDetail) { }
}

export class HandleUserProfileError implements Action {
  public readonly type = HANDLE_USER_PROFILE_ERROR;

  constructor(public readonly payload: Models.ErrorDetail) { }
}

export class HandleTokenRefreshError implements Action {
  public readonly type = HANDLE_TOKEN_REFRESH_ERROR;

  constructor(public readonly payload: Models.ErrorDetail) { }
}

export class ReceiveUserProfile implements Action {
  public readonly type = RECEIVE_USER_PROFILE;

  constructor(public readonly payload: KeycloakProfile) { }
}

export type UiCommandType = AssignKeycloakClient
  | RequestLogin
  | RequestLogout
  | RequestSignup
  | RequestGoOnReturnUrl
  | LoadUserProfile
  | RefreshAccessToken
  | SetOnReturnUrl

export type AdapterCommandType = AssignKeycloakClient
  | MarkBootstrapAsDone
  | MarkBootstrapAsFailed
  | ReportAuthenticated
  | ReportRefreshed
  | ReportAccessTokenExpired
  | ReportRefreshTokenExpired
  | ReportLoggedOut
  | HandleAuthenticationError
  | HandleUserProfileError
  | HandleTokenRefreshError
  | ReceiveUserProfile
;

export type CommandType = UiCommandType | AdapterCommandType;
