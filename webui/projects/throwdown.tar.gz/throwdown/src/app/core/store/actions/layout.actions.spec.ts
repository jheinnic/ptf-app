import { LoadLayouts } from './layout.actions';

describe('LoadLayouts', () => {
  it('should create an instance', () => {
    expect(new LoadLayouts()).toBeTruthy();
  });
});
