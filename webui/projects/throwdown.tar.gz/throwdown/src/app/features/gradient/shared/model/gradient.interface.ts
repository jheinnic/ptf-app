export interface Gradient {
  inner: string;
  outer: string;
}
