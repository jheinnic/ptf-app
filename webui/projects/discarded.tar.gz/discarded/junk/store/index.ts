import {
  ActionReducer,
  ActionReducerMap,
  createFeatureSelector,
  createSelector,
  MetaReducer
} from '@ngrx/store';
import { environment } from '../../../../src/environments/environment';
import * as fromJunk1 from './reducers/junk1.reducer';

export interface IJunk {
  junk1: fromJunk1.State;
}

export const reducers: ActionReducerMap<IJunk> = {
  junk1: fromJunk1.reducer,
};


export const metaReducers: MetaReducer<IJunk>[] = !environment.production ? [] : [];
