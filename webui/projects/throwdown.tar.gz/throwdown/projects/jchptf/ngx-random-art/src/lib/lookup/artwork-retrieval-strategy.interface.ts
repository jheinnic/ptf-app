export interface ArtworkRetrievalStrategy {
  getArtwork(): Promise;
}
