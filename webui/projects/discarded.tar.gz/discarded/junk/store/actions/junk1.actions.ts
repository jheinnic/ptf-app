import { Action } from '@ngrx/store';

export enum Junk1ActionTypes {
  LoadJunk1s = '[Junk1] Load Junk1s'
}

export class LoadJunk1s implements Action {
  readonly type = Junk1ActionTypes.LoadJunk1s;
}

export type Junk1Actions = LoadJunk1s;
