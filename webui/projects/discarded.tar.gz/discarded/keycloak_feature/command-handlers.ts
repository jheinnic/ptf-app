import {Injectable} from '@angular/core';
import {Observable} from 'rxjs/Observable';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/do';
import 'rxjs/add/operator/exhaustMap';
import 'rxjs/add/operator/filter';
import 'rxjs/add/operator/mergeMap';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/skipUntil';
import 'rxjs/add/operator/take';
import 'rxjs/add/operator/withLatestFrom';
import 'rxjs/add/observable/combineLatest';
import 'rxjs/add/observable/of';
import 'rxjs/add/observable/from';
import 'rxjs/add/observable/zip';
import {Actions, Effect} from '@ngrx/effects';
import {Action, Store} from '@ngrx/store';
import {LogService, LogServiceFactory} from 'ng2-log-service';
import * as Commands from './commands';
import {AssignKeycloakClient} from './commands';
import * as Reducer from './reducer';
import {KeycloakClientAssigned} from './events';

@Injectable()
export class CommandHandlers
{
  private readonly logService: LogService;

  isNameAssigned = this.store.select(Reducer.isAuthClientSelectionMade);

  errorIfNameAssigned = this.isNameAssigned.filter((value) => {
    if (value) {
      throw Error('Name already assigned');
    }
    return value;
  })
    .materialize();

  @Effect()
  handleSetClientName$: Observable<Action> =
    this.actions$.ofType(Commands.ASSIGN_KEYCLOAK_CLIENT)
      .withLatestFrom(this.isNameAssigned)
      .map((input: [AssignKeycloakClient, boolean]) => {
        if (input[1]) {
          throw Error('Keycloak client adapter may only be assigned one time');
        }

        return new KeycloakClientAssigned(input[0].payload);
      });

  @Effect()
  requestLogin$: Observable<Action> =
    this.actions$.ofType(Commands.REQUEST_LOGIN)
        return new KeycloakClientAssigned(input[0].payload);
      });

  RequestLogout$: Observable<Action> =
    this.actions$.ofType(Commands.ASSIGN_KEYCLOAK_CLIENT)
      .withLatestFrom(this.isNameAssigned)
      .map((input: [AssignKeycloakClient, boolean]) => {
        if (input[1]) {
          throw Error('Keycloak client adapter may only be assigned one time');
        }

        return new KeycloakClientAssigned(input[0].payload);
      });

  RequestSignup$: Observable<Action> =
    this.actions$.ofType(Commands.ASSIGN_KEYCLOAK_CLIENT)
      .withLatestFrom(this.isNameAssigned)
      .map((input: [AssignKeycloakClient, boolean]) => {
        if (input[1]) {
          throw Error('Keycloak client adapter may only be assigned one time');
        }

        return new KeycloakClientAssigned(input[0].payload);
      });

  RequestGoOnReturnUrl$: Observable<Action> =
    this.actions$.ofType(Commands.ASSIGN_KEYCLOAK_CLIENT)
      .withLatestFrom(this.isNameAssigned)
      .map((input: [AssignKeycloakClient, boolean]) => {
        if (input[1]) {
          throw Error('Keycloak client adapter may only be assigned one time');
        }

        return new KeycloakClientAssigned(input[0].payload);
      });

  LoadUserProfile$: Observable<Action> =
    this.actions$.ofType(Commands.ASSIGN_KEYCLOAK_CLIENT)
      .withLatestFrom(this.isNameAssigned)
      .map((input: [AssignKeycloakClient, boolean]) => {
        if (input[1]) {
          throw Error('Keycloak client adapter may only be assigned one time');
        }

        return new KeycloakClientAssigned(input[0].payload);
      });

  RefreshAccessToken$: Observable<Action> =
    this.actions$.ofType(Commands.ASSIGN_KEYCLOAK_CLIENT)
      .withLatestFrom(this.isNameAssigned)
      .map((input: [AssignKeycloakClient, boolean]) => {
        if (input[1]) {
          throw Error('Keycloak client adapter may only be assigned one time');
        }

        return new KeycloakClientAssigned(input[0].payload);
      });

  SetOnReturnUrl$: Observable<Action> =
    this.actions$.ofType(Commands.ASSIGN_KEYCLOAK_CLIENT)
      .withLatestFrom(this.isNameAssigned)
      .map((input: [AssignKeycloakClient, boolean]) => {
        if (input[1]) {
          throw Error('Keycloak client adapter may only be assigned one time');
        }

        return new KeycloakClientAssigned(input[0].payload);
      });

  MarkBootstrapAsDone$: Observable<Action> =
    this.actions$.ofType(Commands.ASSIGN_KEYCLOAK_CLIENT)
      .withLatestFrom(this.isNameAssigned)
      .map((input: [AssignKeycloakClient, boolean]) => {
        if (input[1]) {
          throw Error('Keycloak client adapter may only be assigned one time');
        }

        return new KeycloakClientAssigned(input[0].payload);
      });

  MarkBootstrapAsFailed$: Observable<Action> =
    this.actions$.ofType(Commands.ASSIGN_KEYCLOAK_CLIENT)
      .withLatestFrom(this.isNameAssigned)
      .map((input: [AssignKeycloakClient, boolean]) => {
        if (input[1]) {
          throw Error('Keycloak client adapter may only be assigned one time');
        }

        return new KeycloakClientAssigned(input[0].payload);
      });

  ReportAuthenticated$: Observable<Action> =
    this.actions$.ofType(Commands.ASSIGN_KEYCLOAK_CLIENT)
      .withLatestFrom(this.isNameAssigned)
      .map((input: [AssignKeycloakClient, boolean]) => {
        if (input[1]) {
          throw Error('Keycloak client adapter may only be assigned one time');
        }

        return new KeycloakClientAssigned(input[0].payload);
      });

  ReportRefreshed$: Observable<Action> =
    this.actions$.ofType(Commands.ASSIGN_KEYCLOAK_CLIENT)
      .withLatestFrom(this.isNameAssigned)
      .map((input: [AssignKeycloakClient, boolean]) => {
        if (input[1]) {
          throw Error('Keycloak client adapter may only be assigned one time');
        }

        return new KeycloakClientAssigned(input[0].payload);
      });

  ReportAccessTokenExpired$: Observable<Action> =
    this.actions$.ofType(Commands.ASSIGN_KEYCLOAK_CLIENT)
      .withLatestFrom(this.isNameAssigned)
      .map((input: [AssignKeycloakClient, boolean]) => {
        if (input[1]) {
          throw Error('Keycloak client adapter may only be assigned one time');
        }

        return new KeycloakClientAssigned(input[0].payload);
      });

  ReportRefreshTokenExpired$: Observable<Action> =
    this.actions$.ofType(Commands.ASSIGN_KEYCLOAK_CLIENT)
      .withLatestFrom(this.isNameAssigned)
      .map((input: [AssignKeycloakClient, boolean]) => {
        if (input[1]) {
          throw Error('Keycloak client adapter may only be assigned one time');
        }

        return new KeycloakClientAssigned(input[0].payload);
      });

  ReportLoggedOut$: Observable<Action> =
    this.actions$.ofType(Commands.ASSIGN_KEYCLOAK_CLIENT)
      .withLatestFrom(this.isNameAssigned)
      .map((input: [AssignKeycloakClient, boolean]) => {
        if (input[1]) {
          throw Error('Keycloak client adapter may only be assigned one time');
        }

        return new KeycloakClientAssigned(input[0].payload);
      });

  HandleAuthenticationError$: Observable<Action> =
    this.actions$.ofType(Commands.ASSIGN_KEYCLOAK_CLIENT)
      .withLatestFrom(this.isNameAssigned)
      .map((input: [AssignKeycloakClient, boolean]) => {
        if (input[1]) {
          throw Error('Keycloak client adapter may only be assigned one time');
        }

        return new KeycloakClientAssigned(input[0].payload);
      });

  HandleUserProfileError$: Observable<Action> =
    this.actions$.ofType(Commands.ASSIGN_KEYCLOAK_CLIENT)
      .withLatestFrom(this.isNameAssigned)
      .map((input: [AssignKeycloakClient, boolean]) => {
        if (input[1]) {
          throw Error('Keycloak client adapter may only be assigned one time');
        }

        return new KeycloakClientAssigned(input[0].payload);
      });

  HandleTokenRefreshError$: Observable<Action> =
    this.actions$.ofType(Commands.ASSIGN_KEYCLOAK_CLIENT)
      .withLatestFrom(this.isNameAssigned)
      .map((input: [AssignKeycloakClient, boolean]) => {
        if (input[1]) {
          throw Error('Keycloak client adapter may only be assigned one time');
        }

        return new KeycloakClientAssigned(input[0].payload);
      });

  ReceiveUserProfile$: Observable<Action> =
    this.actions$.ofType(Commands.ASSIGN_KEYCLOAK_CLIENT)
      .withLatestFrom(this.isNameAssigned)
      .map((input: [AssignKeycloakClient, boolean]) => {
        if (input[1]) {
          throw Error('Keycloak client adapter may only be assigned one time');
        }

        return new KeycloakClientAssigned(input[0].payload);
      });


  constructor(
    logServiceFactory: LogServiceFactory,
    private readonly actions$: Actions,
    private readonly store: Store<Reducer.State>)
  {
    this.logService = logServiceFactory.newLogService();
    this.logService.namespace = 'KeycloakCommandEffects';
    console.log('KeyclockCommandEffects Constructor');

    // this.keycloak.onReady = this.bootstrapSubject.next;
    // this.keycloak.onAuthSuccess = () => { this.bootstrapSubject.next(true); };
    // this.keycloak.onAuthError = (errorData: KeycloakError) => {
    //   this.onAuthErrorSubject.next({
    //     errorCause: ErrorCause.Unknown,
    //     displayMessage: errorData.error_description + ', ' + errorData.error
    //   });
    // };
  }
}
