import {Injectable} from '@angular/core';
import {ALL, ILogListener, ILogMessage, LogLevel} from 'ng2-log-service';

const LOG_LEVEL_LABELS = ['UNUSED', 'All', 'Debug', 'Info', 'Warn', 'Error', 'Fatal'];

@Injectable()
export class MyCustomLogListener
  implements ILogListener
{
  // This contract is not implemented--currently just a pass-through to console.log()
  namespace = ALL;       // what namespace you want to listen for
  level = LogLevel.All;  // what severity you want to start logging at.

  onLog(namespace: string, level: LogLevel, logMessage: ILogMessage) {
    console.log(namespace, LOG_LEVEL_LABELS[level], logMessage.message);
  }
}
