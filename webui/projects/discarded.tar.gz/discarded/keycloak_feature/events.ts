import {Action} from '@ngrx/store';
import * as Models from './models';
import {KeycloakProfile} from 'keycloak-js';

export const KEYCLOAK_CLIENT_ASSIGNED = '(Event::Core Keycloak) Client name assigned'
export const LOGIN_REQUESTED = '(Event::Core Keycloak) Request login';
export const LOGOUT_REQUESTED = '(Event::Core Keycloak) Request logout';
export const SIGNUP_REQUESTED = '(Event::Core Keycloak) Request signup';
export const USER_PROFILE_REQUESTED = '(Event::Core Keycloak) Request user profile';
export const TOKEN_REFRESH_REQUESTED = '(Event::Core Keycloak) Request token refresh';
export const GO_ON_RETURN_REQUESTED = '(Event::Core Keycloak) Go to on-resume URL';
export const ON_RETURN_URL_SET = '(Event::Core Keycloak) Go to on-resume URL';
export const BOOTSTRAP_MARKED_DONE = '(Event::Core Keycloak) Bootstrap marked successful'
export const BOOTSTRAP_MARKED_FAILED = '(Event::Core Keycloak) Bootstrap marked faulty'
export const AUTHENTICATION_REPORTED = '(Event::Core Keycloak) Report authentication success';
export const ACCESS_TOKEN_REFRESHED = '(Event::Core Keycloak) Report access token refresh';
export const ACCESS_TOKEN_EXPIRED = 'Event:Core Keycloak) Report access token expired';
export const REFRESH_TOKEN_EXPIRED = 'Event:Core Keycloak) Report refresh token expired';
export const SESSION_LOGGED_OUT = '(Event::Core Keycloak) Report logged out';
export const AUTHENTICATION_ERROR_RECEIVED = '(Event::Core Keycloak) Receive error details';
export const TOKEN_REFRESH_ERROR_RECEIVED = '(Event::Core Keycloak) Receive error details';
export const USER_PROFILE_ERROR_RECEIVED = '(Event::Core Keycloak) Receive error details';
export const USER_PROFILE_LOADED = '(Event::Core Keycloak) Received user profile';

export class KeycloakClientAssigned implements Action
{
  public readonly type = KEYCLOAK_CLIENT_ASSIGNED;

  constructor (public readonly payload: Models.KeycloakClient) { }
}

export class BootstrapMarkedDone implements Action
{
  public readonly type = BOOTSTRAP_MARKED_DONE;

  constructor(public readonly payload: Models.OnBootstrapResult) { }
}

export class BootstrapMarkedFailed implements Action
{
  public readonly type = BOOTSTRAP_MARKED_FAILED

  constructor(public readonly payload: Models.ErrorDetail) { }
}

export class LoginRequested implements Action
{
  public readonly type = LOGIN_REQUESTED;
}

export class LogoutRequested implements Action
{
  public readonly type = LOGOUT_REQUESTED;
}

export class SignupRequested implements Action
{
  public readonly type = SIGNUP_REQUESTED;
}

export class UserProfileRequested implements Action
{
  public readonly type = USER_PROFILE_REQUESTED;
}

export class TokenRefreshRequested implements Action
{
  public readonly type = TOKEN_REFRESH_REQUESTED;
}

export class OnReturnUrlSet implements Action
{
  public readonly type = ON_RETURN_URL_SET;

  /**
   * @param {string} payload The key assigned to registered on-return URL.
   */
  constructor(public readonly payload: Models.OnReturnUrlKey)
  { }
}

export class AuthenticationReported implements Action
{
  public readonly type = AUTHENTICATION_REPORTED;
}

export class AccessTokenRefreshed implements Action
{
  public readonly type = ACCESS_TOKEN_REFRESHED;
}

export class AccessTokenExpired implements Action
{
  public readonly type = ACCESS_TOKEN_EXPIRED;
}

export class RefreshTokenExpired implements Action
{
  public readonly type = REFRESH_TOKEN_EXPIRED;
}

export class SessionLoggedOut implements Action
{
  public readonly type = SESSION_LOGGED_OUT;
}

export class OnReturnUrlRequested implements Action
{
  public readonly type = GO_ON_RETURN_REQUESTED;

  constructor(public readonly payload: Models.OnReturnUrlKey) { }
}

export class AuthenticationErrorReceived implements Action
{
  public readonly type = AUTHENTICATION_ERROR_RECEIVED;

  constructor(public readonly payload: Models.ErrorDetail) { }
}

export class UserProfileErrorReceived implements Action
{
  public readonly type = USER_PROFILE_ERROR_RECEIVED;

  constructor(public readonly payload: Models.ErrorDetail) { }
}

export class TokenRefreshErrorReceived implements Action
{
  public readonly type = TOKEN_REFRESH_ERROR_RECEIVED;

  constructor(public readonly payload: Models.ErrorDetail) { }
}

export class UserProfileLoaded implements Action
{
  public readonly type = USER_PROFILE_LOADED;

  constructor(public readonly payload: KeycloakProfile) { }
}

export type UiCommandType = KeycloakClientAssigned
  | LoginRequested
  | LogoutRequested
  | SignupRequested
  | UserProfileRequested
  | TokenRefreshRequested
  | OnReturnUrlSet
  | OnReturnUrlRequested

export type AdapterCommandType =
  BootstrapMarkedDone
  | BootstrapMarkedFailed
  | AuthenticationReported
  | AccessTokenRefreshed
  | AccessTokenExpired
  | RefreshTokenExpired
  | SessionLoggedOut
  | AuthenticationErrorReceived
  | TokenRefreshErrorReceived
  | UserProfileErrorReceived
  | UserProfileLoaded
  ;

export type EventType = KeycloakClientAssigned | BootstrapMarkedDone | BootstrapMarkedFailed;
